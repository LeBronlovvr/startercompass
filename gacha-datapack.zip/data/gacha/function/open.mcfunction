scoreboard players set @s gacha 0
dialog show @s gacha:main

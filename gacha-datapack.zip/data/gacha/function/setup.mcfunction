# Run as an operator: /function gacha:setup  (places a machine 2 blocks in front of you)
execute at @s rotated ~ 0 positioned ^ ^ ^2 align xyz run function gacha:place
tellraw @s {"text":"Gacha Machine placed! Players can type /trigger gacha. Tip: build it inside the spawn-protected area so nobody can break it.","color":"green"}

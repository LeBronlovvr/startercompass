scoreboard objectives add gacha trigger
scoreboard objectives add gacha_pick trigger
scoreboard objectives add gacha_pull trigger
scoreboard objectives add gacha_odds trigger
scoreboard objectives add gacha_sel dummy
scoreboard objectives add gacha_anim dummy
scoreboard objectives add gacha_win dummy
scoreboard objectives add gacha_idx dummy
scoreboard objectives add gacha_p dummy
scoreboard objectives add gacha_calc dummy
scoreboard players set #k gacha_calc 31623
scoreboard players set #2 gacha_calc 2
scoreboard players set #10 gacha_calc 10
scoreboard players set #1e7 gacha_calc 10000000
scoreboard players set #t gacha_calc 0
function gacha:db/init

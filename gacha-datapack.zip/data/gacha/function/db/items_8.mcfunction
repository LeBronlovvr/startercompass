data modify storage gacha:db items append value {id:"minecraft:yellow_dye",name:"Yellow Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_glazed_terracotta",name:"Yellow Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_harness",name:"Yellow Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:yellow_poplar_leaves",name:"Yellow Poplar Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_shulker_box",name:"Yellow Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:yellow_stained_glass",name:"Yellow Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_stained_glass_pane",name:"Yellow Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_terracotta",name:"Yellow Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_wool",name:"Yellow Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_wool_slab",name:"Yellow Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_wool_stairs",name:"Yellow Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:zoglin_spawn_egg",name:"Zoglin Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:zombie_head",name:"Zombie Head",value:800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:zombie_horse_spawn_egg",name:"Zombie Horse Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:zombie_nautilus_spawn_egg",name:"Zombie Nautilus Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:zombie_spawn_egg",name:"Zombie Spawn Egg",value:200,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:zombie_villager_spawn_egg",name:"Zombie Villager Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:zombified_piglin_spawn_egg",name:"Zombified Piglin Spawn Egg",value:450,tier:"Epic",color:"light_purple"}

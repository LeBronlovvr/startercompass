data modify storage gacha:db items append value {id:"minecraft:swamp_hut_map",name:"Swamp Hut Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sweet_berries",name:"Sweet Berries",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tadpole_bucket",name:"Tadpole Bucket",value:50,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:tadpole_spawn_egg",name:"Tadpole Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:taiga_village_map",name:"Taiga Village Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:tall_dry_grass",name:"Tall Dry Grass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tall_grass",name:"Tall Grass",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:target",name:"Target",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:terracotta",name:"Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tide_armor_trim_smithing_template",name:"Tide Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:tinted_glass",name:"Tinted Glass",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:tnt",name:"TNT",value:45,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:tnt_minecart",name:"TNT Minecart",value:115,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:torch",name:"Torch",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:torchflower",name:"Torchflower",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:torchflower_seeds",name:"Torchflower Seeds",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:totem_of_undying",name:"Totem of Undying",value:1600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:trader_llama_spawn_egg",name:"Trader Llama Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:trapped_chest",name:"Trapped Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:trial_key",name:"Trial Key",value:200,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:trident",name:"Trident",value:2200,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:tripwire_hook",name:"Tripwire Hook",value:16,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:tropical_fish",name:"Tropical Fish",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tropical_fish_bucket",name:"Tropical Fish Bucket",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tropical_fish_spawn_egg",name:"Tropical Fish Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:tube_coral",name:"Tube Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tube_coral_block",name:"Tube Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tube_coral_fan",name:"Tube Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff",name:"Tuff",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_brick_slab",name:"Tuff Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_brick_stairs",name:"Tuff Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_brick_wall",name:"Tuff Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_bricks",name:"Tuff Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_slab",name:"Tuff Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_stairs",name:"Tuff Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:tuff_wall",name:"Tuff Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:turtle_egg",name:"Turtle Egg",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:turtle_helmet",name:"Turtle Helmet",value:75,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:turtle_scute",name:"Turtle Scute",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:turtle_spawn_egg",name:"Turtle Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:twisting_vines",name:"Twisting Vines",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:verdant_froglight",name:"Verdant Froglight",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:vex_armor_trim_smithing_template",name:"Vex Armor Trim Smithing Template",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:vex_spawn_egg",name:"Vex Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:villager_spawn_egg",name:"Villager Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:vindicator_spawn_egg",name:"Vindicator Spawn Egg",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:vine",name:"Vine",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wandering_trader_spawn_egg",name:"Wandering Trader Spawn Egg",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ward_armor_trim_smithing_template",name:"Ward Armor Trim Smithing Template",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:warden_spawn_egg",name:"Warden Spawn Egg",value:4000,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:warm_ocean_ruins_map",name:"Warm Ocean Ruins Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:warped_button",name:"Warped Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_door",name:"Warped Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_fence",name:"Warped Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_fence_gate",name:"Warped Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_fungus",name:"Warped Fungus",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_fungus_on_a_stick",name:"Warped Fungus on a Stick",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:warped_hanging_sign",name:"Warped Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_hyphae",name:"Warped Hyphae",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_nylium",name:"Warped Nylium",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_planks",name:"Warped Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_pressure_plate",name:"Warped Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_roots",name:"Warped Roots",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_shelf",name:"Warped Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_sign",name:"Warped Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_slab",name:"Warped Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_stairs",name:"Warped Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_stem",name:"Warped Stem",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_trapdoor",name:"Warped Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:warped_wart_block",name:"Warped Wart Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:water_bucket",name:"Water Bucket",value:43,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:waxed_chiseled_copper",name:"Waxed Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_bars",name:"Waxed Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_block",name:"Waxed Copper Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_bulb",name:"Waxed Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_chain",name:"Waxed Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_chest",name:"Waxed Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_door",name:"Waxed Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_golem_statue",name:"Waxed Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_grate",name:"Waxed Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_lantern",name:"Waxed Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_copper_trapdoor",name:"Waxed Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_cut_copper",name:"Waxed Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_cut_copper_slab",name:"Waxed Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_cut_copper_stairs",name:"Waxed Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_chiseled_copper",name:"Waxed Exposed Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper",name:"Waxed Exposed Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_bars",name:"Waxed Exposed Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_bulb",name:"Waxed Exposed Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_chain",name:"Waxed Exposed Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_chest",name:"Waxed Exposed Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_door",name:"Waxed Exposed Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_golem_statue",name:"Waxed Exposed Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_grate",name:"Waxed Exposed Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_lantern",name:"Waxed Exposed Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_copper_trapdoor",name:"Waxed Exposed Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_cut_copper",name:"Waxed Exposed Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_cut_copper_slab",name:"Waxed Exposed Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_cut_copper_stairs",name:"Waxed Exposed Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_exposed_lightning_rod",name:"Waxed Exposed Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_lightning_rod",name:"Waxed Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_chiseled_copper",name:"Waxed Oxidized Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper",name:"Waxed Oxidized Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_bars",name:"Waxed Oxidized Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_bulb",name:"Waxed Oxidized Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_chain",name:"Waxed Oxidized Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_chest",name:"Waxed Oxidized Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_door",name:"Waxed Oxidized Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_golem_statue",name:"Waxed Oxidized Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_grate",name:"Waxed Oxidized Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_lantern",name:"Waxed Oxidized Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_copper_trapdoor",name:"Waxed Oxidized Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_cut_copper",name:"Waxed Oxidized Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_cut_copper_slab",name:"Waxed Oxidized Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_cut_copper_stairs",name:"Waxed Oxidized Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_oxidized_lightning_rod",name:"Waxed Oxidized Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_chiseled_copper",name:"Waxed Weathered Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper",name:"Waxed Weathered Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_bars",name:"Waxed Weathered Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_bulb",name:"Waxed Weathered Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_chain",name:"Waxed Weathered Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_chest",name:"Waxed Weathered Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_door",name:"Waxed Weathered Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_golem_statue",name:"Waxed Weathered Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_grate",name:"Waxed Weathered Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_lantern",name:"Waxed Weathered Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_copper_trapdoor",name:"Waxed Weathered Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_cut_copper",name:"Waxed Weathered Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_cut_copper_slab",name:"Waxed Weathered Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_cut_copper_stairs",name:"Waxed Weathered Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:waxed_weathered_lightning_rod",name:"Waxed Weathered Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wayfinder_armor_trim_smithing_template",name:"Wayfinder Armor Trim Smithing Template",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:weathered_chiseled_copper",name:"Weathered Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper",name:"Weathered Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_bars",name:"Weathered Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_bulb",name:"Weathered Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_chain",name:"Weathered Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_chest",name:"Weathered Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_door",name:"Weathered Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_golem_statue",name:"Weathered Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_grate",name:"Weathered Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_lantern",name:"Weathered Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_copper_trapdoor",name:"Weathered Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_cut_copper",name:"Weathered Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_cut_copper_slab",name:"Weathered Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_cut_copper_stairs",name:"Weathered Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weathered_lightning_rod",name:"Weathered Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:weeping_vines",name:"Weeping Vines",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wet_sponge",name:"Wet Sponge",value:90,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:wheat",name:"Wheat",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wheat_seeds",name:"Wheat Seeds",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_banner",name:"White Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_bed",name:"White Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_bundle",name:"White Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:white_candle",name:"White Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_carpet",name:"White Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_concrete",name:"White Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_concrete_powder",name:"White Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_concrete_slab",name:"White Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_concrete_stairs",name:"White Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_cushion",name:"White Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_dye",name:"White Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_glazed_terracotta",name:"White Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_harness",name:"White Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:white_shulker_box",name:"White Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:white_stained_glass",name:"White Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_stained_glass_pane",name:"White Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_terracotta",name:"White Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_tulip",name:"White Tulip",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_wool",name:"White Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_wool_slab",name:"White Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:white_wool_stairs",name:"White Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wild_armor_trim_smithing_template",name:"Wild Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:wildflowers",name:"Wildflowers",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wind_charge",name:"Wind Charge",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:witch_spawn_egg",name:"Witch Spawn Egg",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:wither_rose",name:"Wither Rose",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:wither_skeleton_skull",name:"Wither Skeleton Skull",value:2600,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:wither_skeleton_spawn_egg",name:"Wither Skeleton Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:wither_spawn_egg",name:"Wither Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:wolf_armor",name:"Wolf Armor",value:70,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:wolf_spawn_egg",name:"Wolf Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:wooden_axe",name:"Wooden Axe",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wooden_hoe",name:"Wooden Hoe",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wooden_pickaxe",name:"Wooden Pickaxe",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wooden_shovel",name:"Wooden Shovel",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wooden_spear",name:"Wooden Spear",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:wooden_sword",name:"Wooden Sword",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:woodland_mansion_map",name:"Woodland Mansion Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:writable_book",name:"Writable Book",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:yellow_banner",name:"Yellow Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_bed",name:"Yellow Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_bundle",name:"Yellow Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:yellow_candle",name:"Yellow Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_carpet",name:"Yellow Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_concrete",name:"Yellow Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_concrete_powder",name:"Yellow Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_concrete_slab",name:"Yellow Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_concrete_stairs",name:"Yellow Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:yellow_cushion",name:"Yellow Cushion",value:6,tier:"Common",color:"gray"}

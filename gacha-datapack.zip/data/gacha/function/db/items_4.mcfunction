data modify storage gacha:db items append value {id:"minecraft:magenta_banner",name:"Magenta Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_bed",name:"Magenta Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_bundle",name:"Magenta Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:magenta_candle",name:"Magenta Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_carpet",name:"Magenta Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_concrete",name:"Magenta Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_concrete_powder",name:"Magenta Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_concrete_slab",name:"Magenta Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_concrete_stairs",name:"Magenta Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_cushion",name:"Magenta Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_dye",name:"Magenta Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_glazed_terracotta",name:"Magenta Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_harness",name:"Magenta Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:magenta_shulker_box",name:"Magenta Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:magenta_stained_glass",name:"Magenta Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_stained_glass_pane",name:"Magenta Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_terracotta",name:"Magenta Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_wool",name:"Magenta Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_wool_slab",name:"Magenta Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magenta_wool_stairs",name:"Magenta Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magma_block",name:"Magma Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:magma_cream",name:"Magma Cream",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:magma_cube_spawn_egg",name:"Magma Cube Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_boat",name:"Mangrove Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_button",name:"Mangrove Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_chest_boat",name:"Mangrove Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_door",name:"Mangrove Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_fence",name:"Mangrove Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_fence_gate",name:"Mangrove Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_hanging_sign",name:"Mangrove Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_leaves",name:"Mangrove Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_log",name:"Mangrove Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_planks",name:"Mangrove Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_pressure_plate",name:"Mangrove Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_propagule",name:"Mangrove Propagule",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_roots",name:"Mangrove Roots",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_shelf",name:"Mangrove Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_sign",name:"Mangrove Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_slab",name:"Mangrove Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_stairs",name:"Mangrove Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_trapdoor",name:"Mangrove Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mangrove_wood",name:"Mangrove Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:map",name:"Map",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:medium_amethyst_bud",name:"Medium Amethyst Bud",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:melon",name:"Melon",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:melon_seeds",name:"Melon Seeds",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:melon_slice",name:"Melon Slice",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:milk_bucket",name:"Milk Bucket",value:45,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:minecart",name:"Minecart",value:70,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:miner_pottery_sherd",name:"Miner Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:mojang_banner_pattern",name:"Mojang Banner Pattern",value:1000,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:mooshroom_spawn_egg",name:"Mooshroom Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:moss_block",name:"Moss Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:moss_carpet",name:"Moss Carpet",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_cobblestone",name:"Mossy Cobblestone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_cobblestone_slab",name:"Mossy Cobblestone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_cobblestone_stairs",name:"Mossy Cobblestone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_cobblestone_wall",name:"Mossy Cobblestone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_stone_brick_slab",name:"Mossy Stone Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_stone_brick_stairs",name:"Mossy Stone Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_stone_brick_wall",name:"Mossy Stone Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mossy_stone_bricks",name:"Mossy Stone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mourner_pottery_sherd",name:"Mourner Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:mud",name:"Mud",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mud_brick_slab",name:"Mud Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mud_brick_stairs",name:"Mud Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mud_brick_wall",name:"Mud Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mud_bricks",name:"Mud Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:muddy_mangrove_roots",name:"Muddy Mangrove Roots",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mule_spawn_egg",name:"Mule Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:mushroom_stem",name:"Mushroom Stem",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mushroom_stew",name:"Mushroom Stew",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_11",name:"Music Disc 11",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_13",name:"Music Disc 13",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_5",name:"Music Disc 5",value:800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_blocks",name:"Music Disc Blocks",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_bounce",name:"Music Disc Bounce",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_cat",name:"Music Disc Cat",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_chirp",name:"Music Disc Chirp",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_creator",name:"Music Disc Creator",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_creator_music_box",name:"Music Disc Creator Music Box",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_far",name:"Music Disc Far",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_lava_chicken",name:"Music Disc Lava Chicken",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_mall",name:"Music Disc Mall",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_mellohi",name:"Music Disc Mellohi",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_otherside",name:"Music Disc Otherside",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_pigstep",name:"Music Disc Pigstep",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_precipice",name:"Music Disc Precipice",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_relic",name:"Music Disc Relic",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_stal",name:"Music Disc Stal",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_strad",name:"Music Disc Strad",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_tears",name:"Music Disc Tears",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_wait",name:"Music Disc Wait",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:music_disc_ward",name:"Music Disc Ward",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:mutton",name:"Mutton",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mycelium",name:"Mycelium",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:name_tag",name:"Name Tag",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:nautilus_shell",name:"Nautilus Shell",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:nautilus_spawn_egg",name:"Nautilus Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:nether_brick",name:"Nether Brick",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_brick_fence",name:"Nether Brick Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_brick_slab",name:"Nether Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_brick_stairs",name:"Nether Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_brick_wall",name:"Nether Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_bricks",name:"Nether Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_gold_ore",name:"Nether Gold Ore",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:nether_quartz_ore",name:"Nether Quartz Ore",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_sprouts",name:"Nether Sprouts",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_star",name:"Nether Star",value:6000,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:nether_wart",name:"Nether Wart",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:nether_wart_block",name:"Nether Wart Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:netherite_axe",name:"Netherite Axe",value:2462,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_block",name:"Netherite Block",value:16200,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_boots",name:"Netherite Boots",value:2582,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_chestplate",name:"Netherite Chestplate",value:3062,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_helmet",name:"Netherite Helmet",value:2702,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_hoe",name:"Netherite Hoe",value:2342,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_horse_armor",name:"Netherite Horse Armor",value:2940,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_ingot",name:"Netherite Ingot",value:1800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:netherite_leggings",name:"Netherite Leggings",value:2942,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_nautilus_armor",name:"Netherite Nautilus Armor",value:2940,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_pickaxe",name:"Netherite Pickaxe",value:2462,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_scrap",name:"Netherite Scrap",value:420,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:netherite_shovel",name:"Netherite Shovel",value:2222,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_spear",name:"Netherite Spear",value:2342,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_sword",name:"Netherite Sword",value:2342,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:netherite_upgrade_smithing_template",name:"Netherite Upgrade Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:netherrack",name:"Netherrack",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:note_block",name:"Note Block",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:oak_boat",name:"Oak Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_button",name:"Oak Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_chest_boat",name:"Oak Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_door",name:"Oak Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_fence",name:"Oak Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_fence_gate",name:"Oak Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_hanging_sign",name:"Oak Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_leaves",name:"Oak Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_log",name:"Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_planks",name:"Oak Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_pressure_plate",name:"Oak Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_sapling",name:"Oak Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_shelf",name:"Oak Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_sign",name:"Oak Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_slab",name:"Oak Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_stairs",name:"Oak Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_trapdoor",name:"Oak Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oak_wood",name:"Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:observer",name:"Observer",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:obsidian",name:"Obsidian",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ocean_monument_map",name:"Ocean Monument Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:ocelot_spawn_egg",name:"Ocelot Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ochre_froglight",name:"Ochre Froglight",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ominous_bottle",name:"Ominous Bottle",value:180,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:ominous_trial_key",name:"Ominous Trial Key",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:open_eyeblossom",name:"Open Eyeblossom",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:orange_banner",name:"Orange Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_bed",name:"Orange Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_bundle",name:"Orange Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:orange_candle",name:"Orange Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_carpet",name:"Orange Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_concrete",name:"Orange Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_concrete_powder",name:"Orange Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_concrete_slab",name:"Orange Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_concrete_stairs",name:"Orange Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_cushion",name:"Orange Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_dye",name:"Orange Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_glazed_terracotta",name:"Orange Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_harness",name:"Orange Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:orange_poplar_leaves",name:"Orange Poplar Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_shulker_box",name:"Orange Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:orange_stained_glass",name:"Orange Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_stained_glass_pane",name:"Orange Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_terracotta",name:"Orange Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_tulip",name:"Orange Tulip",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_wool",name:"Orange Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_wool_slab",name:"Orange Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:orange_wool_stairs",name:"Orange Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxeye_daisy",name:"Oxeye Daisy",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_chiseled_copper",name:"Oxidized Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper",name:"Oxidized Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_bars",name:"Oxidized Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_bulb",name:"Oxidized Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_chain",name:"Oxidized Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_chest",name:"Oxidized Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_door",name:"Oxidized Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_golem_statue",name:"Oxidized Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_grate",name:"Oxidized Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_lantern",name:"Oxidized Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_copper_trapdoor",name:"Oxidized Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_cut_copper",name:"Oxidized Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_cut_copper_slab",name:"Oxidized Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_cut_copper_stairs",name:"Oxidized Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:oxidized_lightning_rod",name:"Oxidized Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:packed_ice",name:"Packed Ice",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:packed_mud",name:"Packed Mud",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:painting",name:"Painting",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_hanging_moss",name:"Pale Hanging Moss",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_moss_block",name:"Pale Moss Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_moss_carpet",name:"Pale Moss Carpet",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_boat",name:"Pale Oak Boat",value:8,tier:"Common",color:"gray"}

data modify storage gacha:db items append value {id:"minecraft:abandoned_camp_map",name:"Abandoned Camp Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:acacia_boat",name:"Acacia Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_button",name:"Acacia Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_chest_boat",name:"Acacia Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_door",name:"Acacia Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_fence",name:"Acacia Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_fence_gate",name:"Acacia Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_hanging_sign",name:"Acacia Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_leaves",name:"Acacia Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_log",name:"Acacia Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_planks",name:"Acacia Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_pressure_plate",name:"Acacia Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_sapling",name:"Acacia Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_shelf",name:"Acacia Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_sign",name:"Acacia Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_slab",name:"Acacia Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_stairs",name:"Acacia Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_trapdoor",name:"Acacia Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:acacia_wood",name:"Acacia Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:activator_rail",name:"Activator Rail",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:allay_spawn_egg",name:"Allay Spawn Egg",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:allium",name:"Allium",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:amethyst_block",name:"Amethyst Block",value:24,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:amethyst_cluster",name:"Amethyst Cluster",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:amethyst_shard",name:"Amethyst Shard",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ancient_debris",name:"Ancient Debris",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:andesite",name:"Andesite",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:andesite_slab",name:"Andesite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:andesite_stairs",name:"Andesite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:andesite_wall",name:"Andesite Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:angler_pottery_sherd",name:"Angler Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:anvil",name:"Anvil",value:200,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:apple",name:"Apple",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:archer_pottery_sherd",name:"Archer Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:armadillo_scute",name:"Armadillo Scute",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:armadillo_spawn_egg",name:"Armadillo Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:armor_stand",name:"Armor Stand",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:arms_up_pottery_sherd",name:"Arms Up Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:arrow",name:"Arrow",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:axolotl_bucket",name:"Axolotl Bucket",value:70,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:axolotl_spawn_egg",name:"Axolotl Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:azalea",name:"Azalea",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:azalea_leaves",name:"Azalea Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:azure_bluet",name:"Azure Bluet",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:baked_potato",name:"Baked Potato",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo",name:"Bamboo",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_block",name:"Bamboo Block",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_button",name:"Bamboo Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_chest_raft",name:"Bamboo Chest Raft",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_door",name:"Bamboo Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_fence",name:"Bamboo Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_fence_gate",name:"Bamboo Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_hanging_sign",name:"Bamboo Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_mosaic",name:"Bamboo Mosaic",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_mosaic_slab",name:"Bamboo Mosaic Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_mosaic_stairs",name:"Bamboo Mosaic Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_planks",name:"Bamboo Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_pressure_plate",name:"Bamboo Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_raft",name:"Bamboo Raft",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_shelf",name:"Bamboo Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_sign",name:"Bamboo Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_slab",name:"Bamboo Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_stairs",name:"Bamboo Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bamboo_trapdoor",name:"Bamboo Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:barrel",name:"Barrel",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:basalt",name:"Basalt",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bat_spawn_egg",name:"Bat Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:beacon",name:"Beacon",value:6500,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:bee_nest",name:"Bee Nest",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bee_spawn_egg",name:"Bee Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:beef",name:"Beef",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:beehive",name:"Beehive",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:beetroot",name:"Beetroot",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:beetroot_seeds",name:"Beetroot Seeds",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:beetroot_soup",name:"Beetroot Soup",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bell",name:"Bell",value:90,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:big_dripleaf",name:"Big Dripleaf",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_boat",name:"Birch Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_button",name:"Birch Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_chest_boat",name:"Birch Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_door",name:"Birch Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_fence",name:"Birch Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_fence_gate",name:"Birch Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_hanging_sign",name:"Birch Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_leaves",name:"Birch Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_log",name:"Birch Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_planks",name:"Birch Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_pressure_plate",name:"Birch Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_sapling",name:"Birch Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_shelf",name:"Birch Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_sign",name:"Birch Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_slab",name:"Birch Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_stairs",name:"Birch Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_trapdoor",name:"Birch Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:birch_wood",name:"Birch Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_banner",name:"Black Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_bed",name:"Black Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_bundle",name:"Black Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:black_candle",name:"Black Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_carpet",name:"Black Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_concrete",name:"Black Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_concrete_powder",name:"Black Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_concrete_slab",name:"Black Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_concrete_stairs",name:"Black Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_cushion",name:"Black Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_dye",name:"Black Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_glazed_terracotta",name:"Black Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_harness",name:"Black Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:black_shulker_box",name:"Black Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:black_stained_glass",name:"Black Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_stained_glass_pane",name:"Black Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_terracotta",name:"Black Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_wool",name:"Black Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_wool_slab",name:"Black Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:black_wool_stairs",name:"Black Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blackstone",name:"Blackstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blackstone_slab",name:"Blackstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blackstone_stairs",name:"Blackstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blackstone_wall",name:"Blackstone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blade_pottery_sherd",name:"Blade Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blast_furnace",name:"Blast Furnace",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blaze_powder",name:"Blaze Powder",value:22,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blaze_rod",name:"Blaze Rod",value:45,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blaze_spawn_egg",name:"Blaze Spawn Egg",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:blue_banner",name:"Blue Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_bed",name:"Blue Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_bundle",name:"Blue Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blue_candle",name:"Blue Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_carpet",name:"Blue Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_concrete",name:"Blue Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_concrete_powder",name:"Blue Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_concrete_slab",name:"Blue Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_concrete_stairs",name:"Blue Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_cushion",name:"Blue Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_dye",name:"Blue Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_egg",name:"Blue Egg",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_glazed_terracotta",name:"Blue Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_harness",name:"Blue Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blue_ice",name:"Blue Ice",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:blue_orchid",name:"Blue Orchid",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_shulker_box",name:"Blue Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:blue_stained_glass",name:"Blue Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_stained_glass_pane",name:"Blue Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_terracotta",name:"Blue Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_wool",name:"Blue Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_wool_slab",name:"Blue Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:blue_wool_stairs",name:"Blue Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bogged_spawn_egg",name:"Bogged Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:bolt_armor_trim_smithing_template",name:"Bolt Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:bone",name:"Bone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bone_block",name:"Bone Block",value:27,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:bone_meal",name:"Bone Meal",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:book",name:"Book",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bookshelf",name:"Bookshelf",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:bordure_indented_banner_pattern",name:"Bordure Indented Banner Pattern",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:bow",name:"Bow",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bowl",name:"Bowl",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brain_coral",name:"Brain Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brain_coral_block",name:"Brain Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brain_coral_fan",name:"Brain Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bread",name:"Bread",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:breeze_rod",name:"Breeze Rod",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:breeze_spawn_egg",name:"Breeze Spawn Egg",value:1200,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:brewer_pottery_sherd",name:"Brewer Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:brewing_stand",name:"Brewing Stand",value:80,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:brick",name:"Brick",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brick_slab",name:"Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brick_stairs",name:"Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brick_wall",name:"Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bricks",name:"Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_banner",name:"Brown Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_bed",name:"Brown Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_bundle",name:"Brown Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:brown_candle",name:"Brown Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_carpet",name:"Brown Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_concrete",name:"Brown Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_concrete_powder",name:"Brown Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_concrete_slab",name:"Brown Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_concrete_stairs",name:"Brown Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_cushion",name:"Brown Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_dye",name:"Brown Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_egg",name:"Brown Egg",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_glazed_terracotta",name:"Brown Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_harness",name:"Brown Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:brown_mushroom",name:"Brown Mushroom",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_mushroom_block",name:"Brown Mushroom Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_shulker_box",name:"Brown Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:brown_stained_glass",name:"Brown Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_stained_glass_pane",name:"Brown Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_terracotta",name:"Brown Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_wool",name:"Brown Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_wool_slab",name:"Brown Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brown_wool_stairs",name:"Brown Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:brush",name:"Brush",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bubble_coral",name:"Bubble Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bubble_coral_block",name:"Bubble Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bubble_coral_fan",name:"Bubble Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:bucket",name:"Bucket",value:42,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:bundle",name:"Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:buried_ancient_city_map",name:"Buried Ancient City Map",value:60,tier:"Uncommon",color:"green"}

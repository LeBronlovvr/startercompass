data modify storage gacha:db items append value {id:"minecraft:red_nether_brick_stairs",name:"Red Nether Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_nether_brick_wall",name:"Red Nether Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_nether_bricks",name:"Red Nether Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_poplar_leaves",name:"Red Poplar Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_sand",name:"Red Sand",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_sandstone",name:"Red Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_sandstone_slab",name:"Red Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_sandstone_stairs",name:"Red Sandstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_sandstone_wall",name:"Red Sandstone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_shrub",name:"Red Shrub",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_shulker_box",name:"Red Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:red_stained_glass",name:"Red Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_stained_glass_pane",name:"Red Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_terracotta",name:"Red Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_tulip",name:"Red Tulip",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_wool",name:"Red Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_wool_slab",name:"Red Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_wool_stairs",name:"Red Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:redstone",name:"Redstone",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:redstone_block",name:"Redstone Block",value:45,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:redstone_lamp",name:"Redstone Lamp",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:redstone_ore",name:"Redstone Ore",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:redstone_torch",name:"Redstone Torch",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:repeater",name:"Repeater",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:resin_block",name:"Resin Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_brick",name:"Resin Brick",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_brick_slab",name:"Resin Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_brick_stairs",name:"Resin Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_brick_wall",name:"Resin Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_bricks",name:"Resin Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:resin_clump",name:"Resin Clump",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:respawn_anchor",name:"Respawn Anchor",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:rib_armor_trim_smithing_template",name:"Rib Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:rooted_dirt",name:"Rooted Dirt",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rose_bush",name:"Rose Bush",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rotten_flesh",name:"Rotten Flesh",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:saddle",name:"Saddle",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:salmon",name:"Salmon",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:salmon_bucket",name:"Salmon Bucket",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:salmon_spawn_egg",name:"Salmon Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sand",name:"Sand",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sandstone",name:"Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sandstone_slab",name:"Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sandstone_stairs",name:"Sandstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sandstone_wall",name:"Sandstone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:savanna_village_map",name:"Savanna Village Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:scaffolding",name:"Scaffolding",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:scrape_pottery_sherd",name:"Scrape Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sculk",name:"Sculk",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sculk_catalyst",name:"Sculk Catalyst",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sculk_sensor",name:"Sculk Sensor",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:sculk_shrieker",name:"Sculk Shrieker",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sculk_vein",name:"Sculk Vein",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sea_lantern",name:"Sea Lantern",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sea_pickle",name:"Sea Pickle",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:seagrass",name:"Seagrass",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sentry_armor_trim_smithing_template",name:"Sentry Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:shaper_armor_trim_smithing_template",name:"Shaper Armor Trim Smithing Template",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sheaf_pottery_sherd",name:"Sheaf Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:shears",name:"Shears",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sheep_spawn_egg",name:"Sheep Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:shelf_mushroom",name:"Shelf Mushroom",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:shelter_pottery_sherd",name:"Shelter Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:shield",name:"Shield",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:short_dry_grass",name:"Short Dry Grass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:short_grass",name:"Short Grass",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:shroomlight",name:"Shroomlight",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:shulker_box",name:"Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:shulker_shell",name:"Shulker Shell",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:shulker_spawn_egg",name:"Shulker Spawn Egg",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:silence_armor_trim_smithing_template",name:"Silence Armor Trim Smithing Template",value:1200,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:silverfish_spawn_egg",name:"Silverfish Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:skeleton_horse_spawn_egg",name:"Skeleton Horse Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:skeleton_skull",name:"Skeleton Skull",value:800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:skeleton_spawn_egg",name:"Skeleton Spawn Egg",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:skull_banner_pattern",name:"Skull Banner Pattern",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:skull_pottery_sherd",name:"Skull Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:slime_ball",name:"Slime Ball",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:slime_block",name:"Slime Block",value:135,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:slime_spawn_egg",name:"Slime Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:small_amethyst_bud",name:"Small Amethyst Bud",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:small_dripleaf",name:"Small Dripleaf",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smithing_table",name:"Smithing Table",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:smoker",name:"Smoker",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_basalt",name:"Smooth Basalt",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_quartz",name:"Smooth Quartz",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_quartz_slab",name:"Smooth Quartz Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_quartz_stairs",name:"Smooth Quartz Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_red_sandstone",name:"Smooth Red Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_red_sandstone_slab",name:"Smooth Red Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_red_sandstone_stairs",name:"Smooth Red Sandstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_sandstone",name:"Smooth Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_sandstone_slab",name:"Smooth Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_sandstone_stairs",name:"Smooth Sandstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_stone",name:"Smooth Stone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:smooth_stone_slab",name:"Smooth Stone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sniffer_egg",name:"Sniffer Egg",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sniffer_spawn_egg",name:"Sniffer Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:snort_pottery_sherd",name:"Snort Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:snout_armor_trim_smithing_template",name:"Snout Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:snow",name:"Snow",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:snow_block",name:"Snow Block",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:snow_golem_spawn_egg",name:"Snow Golem Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:snowball",name:"Snowball",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:snowy_village_map",name:"Snowy Village Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:soul_campfire",name:"Soul Campfire",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:soul_lantern",name:"Soul Lantern",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:soul_sand",name:"Soul Sand",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:soul_soil",name:"Soul Soil",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:soul_torch",name:"Soul Torch",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spectral_arrow",name:"Spectral Arrow",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spider_eye",name:"Spider Eye",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spider_spawn_egg",name:"Spider Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:spire_armor_trim_smithing_template",name:"Spire Armor Trim Smithing Template",value:800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:splash_potion",name:"Splash Potion",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sponge",name:"Sponge",value:90,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:spore_blossom",name:"Spore Blossom",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:spruce_boat",name:"Spruce Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_button",name:"Spruce Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_chest_boat",name:"Spruce Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_door",name:"Spruce Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_fence",name:"Spruce Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_fence_gate",name:"Spruce Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_hanging_sign",name:"Spruce Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_leaves",name:"Spruce Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_log",name:"Spruce Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_planks",name:"Spruce Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_pressure_plate",name:"Spruce Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_sapling",name:"Spruce Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_shelf",name:"Spruce Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_sign",name:"Spruce Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_slab",name:"Spruce Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_stairs",name:"Spruce Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_trapdoor",name:"Spruce Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spruce_wood",name:"Spruce Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:spyglass",name:"Spyglass",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:squid_spawn_egg",name:"Squid Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:stick",name:"Stick",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sticky_piston",name:"Sticky Piston",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:stone",name:"Stone",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_axe",name:"Stone Axe",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_brick_slab",name:"Stone Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_brick_stairs",name:"Stone Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_brick_wall",name:"Stone Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_bricks",name:"Stone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_button",name:"Stone Button",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_hoe",name:"Stone Hoe",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_pickaxe",name:"Stone Pickaxe",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_pressure_plate",name:"Stone Pressure Plate",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_shovel",name:"Stone Shovel",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_slab",name:"Stone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_spear",name:"Stone Spear",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_stairs",name:"Stone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stone_sword",name:"Stone Sword",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stonecutter",name:"Stonecutter",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:straw_bed",name:"Straw Bed",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stray_spawn_egg",name:"Stray Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:strider_spawn_egg",name:"Strider Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:string",name:"String",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_acacia_log",name:"Stripped Acacia Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_acacia_wood",name:"Stripped Acacia Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_bamboo_block",name:"Stripped Bamboo Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_birch_log",name:"Stripped Birch Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_birch_wood",name:"Stripped Birch Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_cherry_log",name:"Stripped Cherry Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_cherry_wood",name:"Stripped Cherry Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_crimson_hyphae",name:"Stripped Crimson Hyphae",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_crimson_stem",name:"Stripped Crimson Stem",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_dark_oak_log",name:"Stripped Dark Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_dark_oak_wood",name:"Stripped Dark Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_jungle_log",name:"Stripped Jungle Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_jungle_wood",name:"Stripped Jungle Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_mangrove_log",name:"Stripped Mangrove Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_mangrove_wood",name:"Stripped Mangrove Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_oak_log",name:"Stripped Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_oak_wood",name:"Stripped Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_pale_oak_log",name:"Stripped Pale Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_pale_oak_wood",name:"Stripped Pale Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_poplar_log",name:"Stripped Poplar Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_poplar_wood",name:"Stripped Poplar Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_spruce_log",name:"Stripped Spruce Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_spruce_wood",name:"Stripped Spruce Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_warped_hyphae",name:"Stripped Warped Hyphae",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:stripped_warped_stem",name:"Stripped Warped Stem",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sugar",name:"Sugar",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sugar_cane",name:"Sugar Cane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur",name:"Sulfur",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_brick_slab",name:"Sulfur Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_brick_stairs",name:"Sulfur Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_brick_wall",name:"Sulfur Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_bricks",name:"Sulfur Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_cube_bucket",name:"Sulfur Cube Bucket",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_cube_spawn_egg",name:"Sulfur Cube Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_slab",name:"Sulfur Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_spike",name:"Sulfur Spike",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_stairs",name:"Sulfur Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sulfur_wall",name:"Sulfur Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:sunflower",name:"Sunflower",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:suspicious_gravel",name:"Suspicious Gravel",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:suspicious_sand",name:"Suspicious Sand",value:3,tier:"Common",color:"gray"}

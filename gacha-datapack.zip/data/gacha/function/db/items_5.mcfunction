data modify storage gacha:db items append value {id:"minecraft:pale_oak_button",name:"Pale Oak Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_chest_boat",name:"Pale Oak Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_door",name:"Pale Oak Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_fence",name:"Pale Oak Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_fence_gate",name:"Pale Oak Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_hanging_sign",name:"Pale Oak Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_leaves",name:"Pale Oak Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_log",name:"Pale Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_planks",name:"Pale Oak Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_pressure_plate",name:"Pale Oak Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_sapling",name:"Pale Oak Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_shelf",name:"Pale Oak Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_sign",name:"Pale Oak Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_slab",name:"Pale Oak Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_stairs",name:"Pale Oak Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_trapdoor",name:"Pale Oak Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pale_oak_wood",name:"Pale Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:panda_spawn_egg",name:"Panda Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:paper",name:"Paper",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:parched_spawn_egg",name:"Parched Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:parrot_spawn_egg",name:"Parrot Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pearlescent_froglight",name:"Pearlescent Froglight",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:peony",name:"Peony",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:phantom_membrane",name:"Phantom Membrane",value:80,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:phantom_spawn_egg",name:"Phantom Spawn Egg",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pig_spawn_egg",name:"Pig Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:piglin_banner_pattern",name:"Piglin Banner Pattern",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:piglin_brute_spawn_egg",name:"Piglin Brute Spawn Egg",value:1000,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:piglin_head",name:"Piglin Head",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:piglin_spawn_egg",name:"Piglin Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pillager_spawn_egg",name:"Pillager Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pink_banner",name:"Pink Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_bed",name:"Pink Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_bundle",name:"Pink Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:pink_candle",name:"Pink Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_carpet",name:"Pink Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_concrete",name:"Pink Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_concrete_powder",name:"Pink Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_concrete_slab",name:"Pink Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_concrete_stairs",name:"Pink Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_cushion",name:"Pink Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_dye",name:"Pink Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_glazed_terracotta",name:"Pink Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_harness",name:"Pink Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:pink_petals",name:"Pink Petals",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_shulker_box",name:"Pink Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pink_stained_glass",name:"Pink Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_stained_glass_pane",name:"Pink Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_terracotta",name:"Pink Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_tulip",name:"Pink Tulip",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_wool",name:"Pink Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_wool_slab",name:"Pink Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pink_wool_stairs",name:"Pink Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:piston",name:"Piston",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:pitcher_plant",name:"Pitcher Plant",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:pitcher_pod",name:"Pitcher Pod",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:plains_village_map",name:"Plains Village Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:plenty_pottery_sherd",name:"Plenty Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:podzol",name:"Podzol",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pointed_dripstone",name:"Pointed Dripstone",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poisonous_potato",name:"Poisonous Potato",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polar_bear_spawn_egg",name:"Polar Bear Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:polished_andesite",name:"Polished Andesite",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_andesite_slab",name:"Polished Andesite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_andesite_stairs",name:"Polished Andesite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_basalt",name:"Polished Basalt",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone",name:"Polished Blackstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_brick_slab",name:"Polished Blackstone Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_brick_stairs",name:"Polished Blackstone Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_brick_wall",name:"Polished Blackstone Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_bricks",name:"Polished Blackstone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_button",name:"Polished Blackstone Button",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_pressure_plate",name:"Polished Blackstone Pressure Plate",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_slab",name:"Polished Blackstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_stairs",name:"Polished Blackstone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_blackstone_wall",name:"Polished Blackstone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_cinnabar",name:"Polished Cinnabar",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_cinnabar_slab",name:"Polished Cinnabar Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_cinnabar_stairs",name:"Polished Cinnabar Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_cinnabar_wall",name:"Polished Cinnabar Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_deepslate",name:"Polished Deepslate",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_deepslate_slab",name:"Polished Deepslate Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_deepslate_stairs",name:"Polished Deepslate Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_deepslate_wall",name:"Polished Deepslate Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_diorite",name:"Polished Diorite",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_diorite_slab",name:"Polished Diorite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_diorite_stairs",name:"Polished Diorite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_granite",name:"Polished Granite",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_granite_slab",name:"Polished Granite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_granite_stairs",name:"Polished Granite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_sulfur",name:"Polished Sulfur",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_sulfur_slab",name:"Polished Sulfur Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_sulfur_stairs",name:"Polished Sulfur Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_sulfur_wall",name:"Polished Sulfur Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_tuff",name:"Polished Tuff",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_tuff_slab",name:"Polished Tuff Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_tuff_stairs",name:"Polished Tuff Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:polished_tuff_wall",name:"Polished Tuff Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_boat",name:"Poplar Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_button",name:"Poplar Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_chest_boat",name:"Poplar Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_door",name:"Poplar Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_fence",name:"Poplar Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_fence_gate",name:"Poplar Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_hanging_sign",name:"Poplar Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_log",name:"Poplar Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_planks",name:"Poplar Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_pressure_plate",name:"Poplar Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_sapling",name:"Poplar Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_shelf",name:"Poplar Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_sign",name:"Poplar Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_slab",name:"Poplar Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_stairs",name:"Poplar Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_trapdoor",name:"Poplar Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poplar_wood",name:"Poplar Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:popped_chorus_fruit",name:"Popped Chorus Fruit",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:poppy",name:"Poppy",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:porkchop",name:"Porkchop",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:potato",name:"Potato",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:potent_sulfur",name:"Potent Sulfur",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:potion",name:"Potion",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:powder_snow_bucket",name:"Powder Snow Bucket",value:44,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:powered_rail",name:"Powered Rail",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:prismarine",name:"Prismarine",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_brick_slab",name:"Prismarine Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_brick_stairs",name:"Prismarine Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_bricks",name:"Prismarine Bricks",value:90,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_crystals",name:"Prismarine Crystals",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_shard",name:"Prismarine Shard",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_slab",name:"Prismarine Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_stairs",name:"Prismarine Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:prismarine_wall",name:"Prismarine Wall",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:prize_pottery_sherd",name:"Prize Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:pufferfish",name:"Pufferfish",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pufferfish_bucket",name:"Pufferfish Bucket",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pufferfish_spawn_egg",name:"Pufferfish Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:pumpkin",name:"Pumpkin",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pumpkin_pie",name:"Pumpkin Pie",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:pumpkin_seeds",name:"Pumpkin Seeds",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_banner",name:"Purple Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_bed",name:"Purple Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_bundle",name:"Purple Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:purple_candle",name:"Purple Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_carpet",name:"Purple Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_concrete",name:"Purple Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_concrete_powder",name:"Purple Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_concrete_slab",name:"Purple Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_concrete_stairs",name:"Purple Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_cushion",name:"Purple Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_dye",name:"Purple Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_glazed_terracotta",name:"Purple Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_harness",name:"Purple Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:purple_shulker_box",name:"Purple Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:purple_stained_glass",name:"Purple Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_stained_glass_pane",name:"Purple Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_terracotta",name:"Purple Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_wool",name:"Purple Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_wool_slab",name:"Purple Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purple_wool_stairs",name:"Purple Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purpur_block",name:"Purpur Block",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purpur_pillar",name:"Purpur Pillar",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purpur_slab",name:"Purpur Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:purpur_stairs",name:"Purpur Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:quartz",name:"Quartz",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:quartz_block",name:"Quartz Block",value:32,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:quartz_bricks",name:"Quartz Bricks",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:quartz_pillar",name:"Quartz Pillar",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:quartz_slab",name:"Quartz Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:quartz_stairs",name:"Quartz Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rabbit",name:"Rabbit",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rabbit_foot",name:"Rabbit Foot",value:50,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:rabbit_hide",name:"Rabbit Hide",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rabbit_spawn_egg",name:"Rabbit Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:rabbit_stew",name:"Rabbit Stew",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:rail",name:"Rail",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:raiser_armor_trim_smithing_template",name:"Raiser Armor Trim Smithing Template",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ravager_spawn_egg",name:"Ravager Spawn Egg",value:1200,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:raw_copper",name:"Raw Copper",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:raw_copper_block",name:"Raw Copper Block",value:54,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:raw_gold",name:"Raw Gold",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:raw_gold_block",name:"Raw Gold Block",value:252,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:raw_iron",name:"Raw Iron",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:raw_iron_block",name:"Raw Iron Block",value:108,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:recovery_compass",name:"Recovery Compass",value:1100,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:red_banner",name:"Red Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_bed",name:"Red Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_bundle",name:"Red Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:red_candle",name:"Red Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_carpet",name:"Red Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_concrete",name:"Red Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_concrete_powder",name:"Red Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_concrete_slab",name:"Red Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_concrete_stairs",name:"Red Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_cushion",name:"Red Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_dye",name:"Red Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_glazed_terracotta",name:"Red Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_harness",name:"Red Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:red_mushroom",name:"Red Mushroom",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_mushroom_block",name:"Red Mushroom Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:red_nether_brick_slab",name:"Red Nether Brick Slab",value:1,tier:"Common",color:"gray"}

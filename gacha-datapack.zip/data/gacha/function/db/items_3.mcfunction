data modify storage gacha:db items append value {id:"minecraft:gray_bed",name:"Gray Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_bundle",name:"Gray Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:gray_candle",name:"Gray Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_carpet",name:"Gray Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_concrete",name:"Gray Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_concrete_powder",name:"Gray Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_concrete_slab",name:"Gray Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_concrete_stairs",name:"Gray Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_cushion",name:"Gray Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_dye",name:"Gray Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_glazed_terracotta",name:"Gray Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_harness",name:"Gray Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:gray_shulker_box",name:"Gray Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:gray_stained_glass",name:"Gray Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_stained_glass_pane",name:"Gray Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_terracotta",name:"Gray Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_wool",name:"Gray Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_wool_slab",name:"Gray Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_wool_stairs",name:"Gray Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_banner",name:"Green Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_bed",name:"Green Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_bundle",name:"Green Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:green_candle",name:"Green Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_carpet",name:"Green Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_concrete",name:"Green Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_concrete_powder",name:"Green Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_concrete_slab",name:"Green Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_concrete_stairs",name:"Green Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_cushion",name:"Green Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_dye",name:"Green Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_glazed_terracotta",name:"Green Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_harness",name:"Green Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:green_shulker_box",name:"Green Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:green_stained_glass",name:"Green Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_stained_glass_pane",name:"Green Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_terracotta",name:"Green Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_wool",name:"Green Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_wool_slab",name:"Green Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:green_wool_stairs",name:"Green Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:grindstone",name:"Grindstone",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:guardian_spawn_egg",name:"Guardian Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:gunpowder",name:"Gunpowder",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:guster_banner_pattern",name:"Guster Banner Pattern",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:guster_pottery_sherd",name:"Guster Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:hanging_roots",name:"Hanging Roots",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:happy_ghast_spawn_egg",name:"Happy Ghast Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:hay_block",name:"Hay Block",value:27,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:heart_of_the_sea",name:"Heart of the Sea",value:1500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:heart_pottery_sherd",name:"Heart Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:heartbreak_pottery_sherd",name:"Heartbreak Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:heavy_core",name:"Heavy Core",value:2500,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:heavy_weighted_pressure_plate",name:"Heavy Weighted Pressure Plate",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:hoglin_spawn_egg",name:"Hoglin Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:honey_block",name:"Honey Block",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:honey_bottle",name:"Honey Bottle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:honeycomb",name:"Honeycomb",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:honeycomb_block",name:"Honeycomb Block",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:hopper",name:"Hopper",value:50,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:hopper_minecart",name:"Hopper Minecart",value:125,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:horn_coral",name:"Horn Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:horn_coral_block",name:"Horn Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:horn_coral_fan",name:"Horn Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:horse_spawn_egg",name:"Horse Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:host_armor_trim_smithing_template",name:"Host Armor Trim Smithing Template",value:500,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:howl_pottery_sherd",name:"Howl Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:husk_spawn_egg",name:"Husk Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ice",name:"Ice",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ink_sac",name:"Ink Sac",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_axe",name:"Iron Axe",value:44,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_bars",name:"Iron Bars",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_block",name:"Iron Block",value:126,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:iron_boots",name:"Iron Boots",value:56,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_chain",name:"Iron Chain",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_chestplate",name:"Iron Chestplate",value:112,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:iron_door",name:"Iron Door",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_golem_spawn_egg",name:"Iron Golem Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:iron_helmet",name:"Iron Helmet",value:70,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_hoe",name:"Iron Hoe",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_horse_armor",name:"Iron Horse Armor",value:98,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:iron_ingot",name:"Iron Ingot",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_leggings",name:"Iron Leggings",value:98,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:iron_nautilus_armor",name:"Iron Nautilus Armor",value:98,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:iron_nugget",name:"Iron Nugget",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_ore",name:"Iron Ore",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:iron_pickaxe",name:"Iron Pickaxe",value:44,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_shovel",name:"Iron Shovel",value:16,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_spear",name:"Iron Spear",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_sword",name:"Iron Sword",value:29,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:iron_trapdoor",name:"Iron Trapdoor",value:56,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:item_frame",name:"Item Frame",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jack_o_lantern",name:"Jack O Lantern",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jukebox",name:"Jukebox",value:140,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:jungle_boat",name:"Jungle Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_button",name:"Jungle Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_chest_boat",name:"Jungle Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_door",name:"Jungle Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_fence",name:"Jungle Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_fence_gate",name:"Jungle Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_hanging_sign",name:"Jungle Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_leaves",name:"Jungle Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_log",name:"Jungle Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_planks",name:"Jungle Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_pressure_plate",name:"Jungle Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_pyramid_map",name:"Jungle Pyramid Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:jungle_sapling",name:"Jungle Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_shelf",name:"Jungle Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_sign",name:"Jungle Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_slab",name:"Jungle Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_stairs",name:"Jungle Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_trapdoor",name:"Jungle Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:jungle_wood",name:"Jungle Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:kelp",name:"Kelp",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ladder",name:"Ladder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lantern",name:"Lantern",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lapis_block",name:"Lapis Block",value:72,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lapis_lazuli",name:"Lapis Lazuli",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lapis_ore",name:"Lapis Ore",value:32,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:large_amethyst_bud",name:"Large Amethyst Bud",value:18,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:large_fern",name:"Large Fern",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lava_bucket",name:"Lava Bucket",value:50,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lead",name:"Lead",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:leaf_litter",name:"Leaf Litter",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:leather",name:"Leather",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:leather_boots",name:"Leather Boots",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:leather_chestplate",name:"Leather Chestplate",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:leather_helmet",name:"Leather Helmet",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:leather_horse_armor",name:"Leather Horse Armor",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:leather_leggings",name:"Leather Leggings",value:35,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lectern",name:"Lectern",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lever",name:"Lever",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_banner",name:"Light Blue Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_bed",name:"Light Blue Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_bundle",name:"Light Blue Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_candle",name:"Light Blue Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_carpet",name:"Light Blue Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_concrete",name:"Light Blue Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_concrete_powder",name:"Light Blue Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_concrete_slab",name:"Light Blue Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_concrete_stairs",name:"Light Blue Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_cushion",name:"Light Blue Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_dye",name:"Light Blue Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_glazed_terracotta",name:"Light Blue Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_harness",name:"Light Blue Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_shulker_box",name:"Light Blue Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_stained_glass",name:"Light Blue Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_stained_glass_pane",name:"Light Blue Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_terracotta",name:"Light Blue Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_wool",name:"Light Blue Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_wool_slab",name:"Light Blue Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_blue_wool_stairs",name:"Light Blue Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_banner",name:"Light Gray Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_bed",name:"Light Gray Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_bundle",name:"Light Gray Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_candle",name:"Light Gray Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_carpet",name:"Light Gray Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_concrete",name:"Light Gray Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_concrete_powder",name:"Light Gray Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_concrete_slab",name:"Light Gray Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_concrete_stairs",name:"Light Gray Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_cushion",name:"Light Gray Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_dye",name:"Light Gray Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_glazed_terracotta",name:"Light Gray Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_harness",name:"Light Gray Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_shulker_box",name:"Light Gray Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_stained_glass",name:"Light Gray Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_stained_glass_pane",name:"Light Gray Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_terracotta",name:"Light Gray Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_wool",name:"Light Gray Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_wool_slab",name:"Light Gray Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_gray_wool_stairs",name:"Light Gray Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:light_weighted_pressure_plate",name:"Light Weighted Pressure Plate",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lightning_rod",name:"Lightning Rod",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lilac",name:"Lilac",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lily_of_the_valley",name:"Lily of the Valley",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lily_pad",name:"Lily Pad",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_banner",name:"Lime Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_bed",name:"Lime Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_bundle",name:"Lime Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lime_candle",name:"Lime Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_carpet",name:"Lime Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_concrete",name:"Lime Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_concrete_powder",name:"Lime Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_concrete_slab",name:"Lime Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_concrete_stairs",name:"Lime Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_cushion",name:"Lime Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_dye",name:"Lime Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_glazed_terracotta",name:"Lime Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_harness",name:"Lime Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:lime_shulker_box",name:"Lime Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:lime_stained_glass",name:"Lime Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_stained_glass_pane",name:"Lime Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_terracotta",name:"Lime Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_wool",name:"Lime Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_wool_slab",name:"Lime Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lime_wool_stairs",name:"Lime Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:lingering_potion",name:"Lingering Potion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:llama_spawn_egg",name:"Llama Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:lodestone",name:"Lodestone",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:loom",name:"Loom",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:mace",name:"Mace",value:5500,tier:"Legendary",color:"gold"}

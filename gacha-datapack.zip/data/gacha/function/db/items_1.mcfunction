data modify storage gacha:db items append value {id:"minecraft:buried_mineshaft_map",name:"Buried Mineshaft Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:buried_treasure_map",name:"Buried Treasure Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:buried_trial_chambers_map",name:"Buried Trial Chambers Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:burn_pottery_sherd",name:"Burn Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:bush",name:"Bush",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cactus",name:"Cactus",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cactus_flower",name:"Cactus Flower",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cake",name:"Cake",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:calcite",name:"Calcite",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:calibrated_sculk_sensor",name:"Calibrated Sculk Sensor",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:camel_husk_spawn_egg",name:"Camel Husk Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:camel_spawn_egg",name:"Camel Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:campfire",name:"Campfire",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:candle",name:"Candle",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:carrot",name:"Carrot",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:carrot_on_a_stick",name:"Carrot on a Stick",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cartography_table",name:"Cartography Table",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:carved_pumpkin",name:"Carved Pumpkin",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cat_spawn_egg",name:"Cat Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:cauldron",name:"Cauldron",value:70,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:cave_spider_spawn_egg",name:"Cave Spider Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:chainmail_boots",name:"Chainmail Boots",value:88,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:chainmail_chestplate",name:"Chainmail Chestplate",value:176,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:chainmail_helmet",name:"Chainmail Helmet",value:110,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:chainmail_leggings",name:"Chainmail Leggings",value:154,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:charcoal",name:"Charcoal",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_boat",name:"Cherry Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_button",name:"Cherry Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_chest_boat",name:"Cherry Chest Boat",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_door",name:"Cherry Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_fence",name:"Cherry Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_fence_gate",name:"Cherry Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_hanging_sign",name:"Cherry Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_leaves",name:"Cherry Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_log",name:"Cherry Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_planks",name:"Cherry Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_pressure_plate",name:"Cherry Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_sapling",name:"Cherry Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_shelf",name:"Cherry Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_sign",name:"Cherry Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_slab",name:"Cherry Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_stairs",name:"Cherry Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_trapdoor",name:"Cherry Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cherry_wood",name:"Cherry Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chest",name:"Chest",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chest_minecart",name:"Chest Minecart",value:75,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:chicken",name:"Chicken",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chicken_spawn_egg",name:"Chicken Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:chipped_anvil",name:"Chipped Anvil",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_bookshelf",name:"Chiseled Bookshelf",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_cinnabar",name:"Chiseled Cinnabar",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_copper",name:"Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_deepslate",name:"Chiseled Deepslate",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_nether_bricks",name:"Chiseled Nether Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_polished_blackstone",name:"Chiseled Polished Blackstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_quartz_block",name:"Chiseled Quartz Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_red_sandstone",name:"Chiseled Red Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_resin_bricks",name:"Chiseled Resin Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_sandstone",name:"Chiseled Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_stone_bricks",name:"Chiseled Stone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_sulfur",name:"Chiseled Sulfur",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_tuff",name:"Chiseled Tuff",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chiseled_tuff_bricks",name:"Chiseled Tuff Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:chorus_flower",name:"Chorus Flower",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:chorus_fruit",name:"Chorus Fruit",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar",name:"Cinnabar",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_brick_slab",name:"Cinnabar Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_brick_stairs",name:"Cinnabar Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_brick_wall",name:"Cinnabar Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_bricks",name:"Cinnabar Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_slab",name:"Cinnabar Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_stairs",name:"Cinnabar Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cinnabar_wall",name:"Cinnabar Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:clay",name:"Clay",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:clay_ball",name:"Clay Ball",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:clock",name:"Clock",value:35,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:closed_eyeblossom",name:"Closed Eyeblossom",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:coal",name:"Coal",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:coal_block",name:"Coal Block",value:36,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:coal_ore",name:"Coal Ore",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:coarse_dirt",name:"Coarse Dirt",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:coast_armor_trim_smithing_template",name:"Coast Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:cobbled_deepslate",name:"Cobbled Deepslate",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobbled_deepslate_slab",name:"Cobbled Deepslate Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobbled_deepslate_stairs",name:"Cobbled Deepslate Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobbled_deepslate_wall",name:"Cobbled Deepslate Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobblestone",name:"Cobblestone",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobblestone_slab",name:"Cobblestone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobblestone_stairs",name:"Cobblestone Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobblestone_wall",name:"Cobblestone Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cobweb",name:"Cobweb",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cocoa_beans",name:"Cocoa Beans",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cod",name:"Cod",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cod_bucket",name:"Cod Bucket",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cod_spawn_egg",name:"Cod Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:comparator",name:"Comparator",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:compass",name:"Compass",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:composter",name:"Composter",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:conduit",name:"Conduit",value:3600,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:cooked_beef",name:"Cooked Beef",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_chicken",name:"Cooked Chicken",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_cod",name:"Cooked Cod",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_mutton",name:"Cooked Mutton",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_porkchop",name:"Cooked Porkchop",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_rabbit",name:"Cooked Rabbit",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cooked_salmon",name:"Cooked Salmon",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cookie",name:"Cookie",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_axe",name:"Copper Axe",value:26,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_bars",name:"Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_block",name:"Copper Block",value:72,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_boots",name:"Copper Boots",value:32,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_bulb",name:"Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_chain",name:"Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_chest",name:"Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_chestplate",name:"Copper Chestplate",value:64,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_door",name:"Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_golem_spawn_egg",name:"Copper Golem Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:copper_golem_statue",name:"Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_grate",name:"Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_helmet",name:"Copper Helmet",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_hoe",name:"Copper Hoe",value:18,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_horse_armor",name:"Copper Horse Armor",value:56,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_ingot",name:"Copper Ingot",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_lantern",name:"Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_leggings",name:"Copper Leggings",value:56,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_nautilus_armor",name:"Copper Nautilus Armor",value:56,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_nugget",name:"Copper Nugget",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_ore",name:"Copper Ore",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_pickaxe",name:"Copper Pickaxe",value:26,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_shovel",name:"Copper Shovel",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_spear",name:"Copper Spear",value:18,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_sword",name:"Copper Sword",value:17,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:copper_torch",name:"Copper Torch",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:copper_trapdoor",name:"Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cornflower",name:"Cornflower",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cow_spawn_egg",name:"Cow Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:cracked_deepslate_bricks",name:"Cracked Deepslate Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cracked_deepslate_tiles",name:"Cracked Deepslate Tiles",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cracked_nether_bricks",name:"Cracked Nether Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cracked_polished_blackstone_bricks",name:"Cracked Polished Blackstone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cracked_stone_bricks",name:"Cracked Stone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crafter",name:"Crafter",value:100,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:crafting_table",name:"Crafting Table",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:creaking_heart",name:"Creaking Heart",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:creaking_spawn_egg",name:"Creaking Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:creeper_banner_pattern",name:"Creeper Banner Pattern",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:creeper_head",name:"Creeper Head",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:creeper_spawn_egg",name:"Creeper Spawn Egg",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:crimson_button",name:"Crimson Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_door",name:"Crimson Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_fence",name:"Crimson Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_fence_gate",name:"Crimson Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_fungus",name:"Crimson Fungus",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_hanging_sign",name:"Crimson Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_hyphae",name:"Crimson Hyphae",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_nylium",name:"Crimson Nylium",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_planks",name:"Crimson Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_pressure_plate",name:"Crimson Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_roots",name:"Crimson Roots",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_shelf",name:"Crimson Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_sign",name:"Crimson Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_slab",name:"Crimson Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_stairs",name:"Crimson Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_stem",name:"Crimson Stem",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crimson_trapdoor",name:"Crimson Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:crossbow",name:"Crossbow",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:crying_obsidian",name:"Crying Obsidian",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:cut_copper",name:"Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_copper_slab",name:"Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_copper_stairs",name:"Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_red_sandstone",name:"Cut Red Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_red_sandstone_slab",name:"Cut Red Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_sandstone",name:"Cut Sandstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cut_sandstone_slab",name:"Cut Sandstone Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_banner",name:"Cyan Banner",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_bed",name:"Cyan Bed",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_bundle",name:"Cyan Bundle",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:cyan_candle",name:"Cyan Candle",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_carpet",name:"Cyan Carpet",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_concrete",name:"Cyan Concrete",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_concrete_powder",name:"Cyan Concrete Powder",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_concrete_slab",name:"Cyan Concrete Slab",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_concrete_stairs",name:"Cyan Concrete Stairs",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_cushion",name:"Cyan Cushion",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_dye",name:"Cyan Dye",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_glazed_terracotta",name:"Cyan Glazed Terracotta",value:5,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_harness",name:"Cyan Harness",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:cyan_shulker_box",name:"Cyan Shulker Box",value:920,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:cyan_stained_glass",name:"Cyan Stained Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_stained_glass_pane",name:"Cyan Stained Glass Pane",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_terracotta",name:"Cyan Terracotta",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_wool",name:"Cyan Wool",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_wool_slab",name:"Cyan Wool Slab",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:cyan_wool_stairs",name:"Cyan Wool Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:damaged_anvil",name:"Damaged Anvil",value:100,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:dandelion",name:"Dandelion",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:danger_pottery_sherd",name:"Danger Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_boat",name:"Dark Oak Boat",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_button",name:"Dark Oak Button",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_chest_boat",name:"Dark Oak Chest Boat",value:10,tier:"Common",color:"gray"}

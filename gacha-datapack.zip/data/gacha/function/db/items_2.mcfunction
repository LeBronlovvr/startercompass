data modify storage gacha:db items append value {id:"minecraft:dark_oak_door",name:"Dark Oak Door",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_fence",name:"Dark Oak Fence",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_fence_gate",name:"Dark Oak Fence Gate",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_hanging_sign",name:"Dark Oak Hanging Sign",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_leaves",name:"Dark Oak Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_log",name:"Dark Oak Log",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_planks",name:"Dark Oak Planks",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_pressure_plate",name:"Dark Oak Pressure Plate",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_sapling",name:"Dark Oak Sapling",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_shelf",name:"Dark Oak Shelf",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_sign",name:"Dark Oak Sign",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_slab",name:"Dark Oak Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_stairs",name:"Dark Oak Stairs",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_trapdoor",name:"Dark Oak Trapdoor",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_oak_wood",name:"Dark Oak Wood",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_prismarine",name:"Dark Prismarine",value:100,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:dark_prismarine_slab",name:"Dark Prismarine Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dark_prismarine_stairs",name:"Dark Prismarine Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:daylight_detector",name:"Daylight Detector",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:dead_brain_coral",name:"Dead Brain Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_brain_coral_block",name:"Dead Brain Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_brain_coral_fan",name:"Dead Brain Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_bubble_coral",name:"Dead Bubble Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_bubble_coral_block",name:"Dead Bubble Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_bubble_coral_fan",name:"Dead Bubble Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_bush",name:"Dead Bush",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_fire_coral",name:"Dead Fire Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_fire_coral_block",name:"Dead Fire Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_fire_coral_fan",name:"Dead Fire Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_horn_coral",name:"Dead Horn Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_horn_coral_block",name:"Dead Horn Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_horn_coral_fan",name:"Dead Horn Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_tube_coral",name:"Dead Tube Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_tube_coral_block",name:"Dead Tube Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dead_tube_coral_fan",name:"Dead Tube Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:decorated_pot",name:"Decorated Pot",value:18,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:deepslate",name:"Deepslate",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_brick_slab",name:"Deepslate Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_brick_stairs",name:"Deepslate Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_brick_wall",name:"Deepslate Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_bricks",name:"Deepslate Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_coal_ore",name:"Deepslate Coal Ore",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_copper_ore",name:"Deepslate Copper Ore",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_diamond_ore",name:"Deepslate Diamond Ore",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_emerald_ore",name:"Deepslate Emerald Ore",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_gold_ore",name:"Deepslate Gold Ore",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_iron_ore",name:"Deepslate Iron Ore",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_lapis_ore",name:"Deepslate Lapis Ore",value:32,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_redstone_ore",name:"Deepslate Redstone Ore",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_tile_slab",name:"Deepslate Tile Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_tile_stairs",name:"Deepslate Tile Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_tile_wall",name:"Deepslate Tile Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:deepslate_tiles",name:"Deepslate Tiles",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:desert_pyramid_map",name:"Desert Pyramid Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:desert_village_map",name:"Desert Village Map",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:detector_rail",name:"Detector Rail",value:20,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:diamond",name:"Diamond",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_axe",name:"Diamond Axe",value:362,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_block",name:"Diamond Block",value:1080,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_boots",name:"Diamond Boots",value:480,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_chestplate",name:"Diamond Chestplate",value:960,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_helmet",name:"Diamond Helmet",value:600,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_hoe",name:"Diamond Hoe",value:242,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_horse_armor",name:"Diamond Horse Armor",value:840,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_leggings",name:"Diamond Leggings",value:840,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_nautilus_armor",name:"Diamond Nautilus Armor",value:840,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:diamond_ore",name:"Diamond Ore",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_pickaxe",name:"Diamond Pickaxe",value:362,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_shovel",name:"Diamond Shovel",value:122,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_spear",name:"Diamond Spear",value:242,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diamond_sword",name:"Diamond Sword",value:241,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:diorite",name:"Diorite",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:diorite_slab",name:"Diorite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:diorite_stairs",name:"Diorite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:diorite_wall",name:"Diorite Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dirt",name:"Dirt",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:disc_fragment_5",name:"Disc Fragment 5",value:80,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:dispenser",name:"Dispenser",value:25,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:dolphin_spawn_egg",name:"Dolphin Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:donkey_spawn_egg",name:"Donkey Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:dragon_breath",name:"Dragon Breath",value:220,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:dragon_egg",name:"Dragon Egg",value:9000,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:dragon_head",name:"Dragon Head",value:3500,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:dried_ghast",name:"Dried Ghast",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:dried_kelp",name:"Dried Kelp",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dried_kelp_block",name:"Dried Kelp Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dripstone_block",name:"Dripstone Block",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:dropper",name:"Dropper",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:drowned_spawn_egg",name:"Drowned Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:dune_armor_trim_smithing_template",name:"Dune Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:echo_shard",name:"Echo Shard",value:220,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:egg",name:"Egg",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:elder_guardian_spawn_egg",name:"Elder Guardian Spawn Egg",value:3000,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:elytra",name:"Elytra",value:3162,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:emerald",name:"Emerald",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:emerald_block",name:"Emerald Block",value:540,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:emerald_ore",name:"Emerald Ore",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:enchanted_golden_apple",name:"Enchanted Golden Apple",value:4500,tier:"Legendary",color:"gold"}
data modify storage gacha:db items append value {id:"minecraft:enchanting_table",name:"Enchanting Table",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:end_crystal",name:"End Crystal",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:end_rod",name:"End Rod",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:end_stone",name:"End Stone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:end_stone_brick_slab",name:"End Stone Brick Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:end_stone_brick_stairs",name:"End Stone Brick Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:end_stone_brick_wall",name:"End Stone Brick Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:end_stone_bricks",name:"End Stone Bricks",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:ender_chest",name:"Ender Chest",value:140,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:ender_dragon_spawn_egg",name:"Ender Dragon Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ender_eye",name:"Ender Eye",value:90,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:ender_pearl",name:"Ender Pearl",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:enderman_spawn_egg",name:"Enderman Spawn Egg",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:endermite_spawn_egg",name:"Endermite Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:evoker_spawn_egg",name:"Evoker Spawn Egg",value:900,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:experience_bottle",name:"Experience Bottle",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:explorer_pottery_sherd",name:"Explorer Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:exposed_chiseled_copper",name:"Exposed Chiseled Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper",name:"Exposed Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_bars",name:"Exposed Copper Bars",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_bulb",name:"Exposed Copper Bulb",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_chain",name:"Exposed Copper Chain",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_chest",name:"Exposed Copper Chest",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_door",name:"Exposed Copper Door",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_golem_statue",name:"Exposed Copper Golem Statue",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_grate",name:"Exposed Copper Grate",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_lantern",name:"Exposed Copper Lantern",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_copper_trapdoor",name:"Exposed Copper Trapdoor",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_cut_copper",name:"Exposed Cut Copper",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_cut_copper_slab",name:"Exposed Cut Copper Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_cut_copper_stairs",name:"Exposed Cut Copper Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:exposed_lightning_rod",name:"Exposed Lightning Rod",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:eye_armor_trim_smithing_template",name:"Eye Armor Trim Smithing Template",value:700,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:feather",name:"Feather",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fermented_spider_eye",name:"Fermented Spider Eye",value:9,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fern",name:"Fern",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:field_masoned_banner_pattern",name:"Field Masoned Banner Pattern",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:fire_charge",name:"Fire Charge",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fire_coral",name:"Fire Coral",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fire_coral_block",name:"Fire Coral Block",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fire_coral_fan",name:"Fire Coral Fan",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:firefly_bush",name:"Firefly Bush",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:firework_rocket",name:"Firework Rocket",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fishing_rod",name:"Fishing Rod",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fletching_table",name:"Fletching Table",value:8,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:flint",name:"Flint",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:flint_and_steel",name:"Flint and Steel",value:15,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:flow_armor_trim_smithing_template",name:"Flow Armor Trim Smithing Template",value:300,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:flow_banner_pattern",name:"Flow Banner Pattern",value:400,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:flow_pottery_sherd",name:"Flow Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:flower_banner_pattern",name:"Flower Banner Pattern",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:flower_pot",name:"Flower Pot",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:flowering_azalea",name:"Flowering Azalea",value:10,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:flowering_azalea_leaves",name:"Flowering Azalea Leaves",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:fox_spawn_egg",name:"Fox Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:friend_pottery_sherd",name:"Friend Pottery Sherd",value:60,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:frog_spawn_egg",name:"Frog Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:furnace",name:"Furnace",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:furnace_minecart",name:"Furnace Minecart",value:75,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:ghast_spawn_egg",name:"Ghast Spawn Egg",value:800,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:ghast_tear",name:"Ghast Tear",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:gilded_blackstone",name:"Gilded Blackstone",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glass",name:"Glass",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glass_bottle",name:"Glass Bottle",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glass_pane",name:"Glass Pane",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glistering_melon_slice",name:"Glistering Melon Slice",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:globe_banner_pattern",name:"Globe Banner Pattern",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:glow_berries",name:"Glow Berries",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glow_ink_sac",name:"Glow Ink Sac",value:12,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glow_item_frame",name:"Glow Item Frame",value:14,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glow_lichen",name:"Glow Lichen",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:glow_squid_spawn_egg",name:"Glow Squid Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:glowstone",name:"Glowstone",value:24,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:glowstone_dust",name:"Glowstone Dust",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:goat_horn",name:"Goat Horn",value:350,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:goat_spawn_egg",name:"Goat Spawn Egg",value:450,tier:"Epic",color:"light_purple"}
data modify storage gacha:db items append value {id:"minecraft:gold_block",name:"Gold Block",value:270,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:gold_ingot",name:"Gold Ingot",value:30,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:gold_nugget",name:"Gold Nugget",value:4,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gold_ore",name:"Gold Ore",value:28,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:golden_apple",name:"Golden Apple",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_axe",name:"Golden Axe",value:92,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_boots",name:"Golden Boots",value:120,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_carrot",name:"Golden Carrot",value:6,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:golden_chestplate",name:"Golden Chestplate",value:240,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_dandelion",name:"Golden Dandelion",value:40,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:golden_helmet",name:"Golden Helmet",value:150,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_hoe",name:"Golden Hoe",value:62,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:golden_horse_armor",name:"Golden Horse Armor",value:210,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_leggings",name:"Golden Leggings",value:210,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_nautilus_armor",name:"Golden Nautilus Armor",value:210,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_pickaxe",name:"Golden Pickaxe",value:92,tier:"Rare",color:"aqua"}
data modify storage gacha:db items append value {id:"minecraft:golden_shovel",name:"Golden Shovel",value:32,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:golden_spear",name:"Golden Spear",value:62,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:golden_sword",name:"Golden Sword",value:61,tier:"Uncommon",color:"green"}
data modify storage gacha:db items append value {id:"minecraft:granite",name:"Granite",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:granite_slab",name:"Granite Slab",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:granite_stairs",name:"Granite Stairs",value:2,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:granite_wall",name:"Granite Wall",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:grass_block",name:"Grass Block",value:3,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gravel",name:"Gravel",value:1,tier:"Common",color:"gray"}
data modify storage gacha:db items append value {id:"minecraft:gray_banner",name:"Gray Banner",value:14,tier:"Common",color:"gray"}

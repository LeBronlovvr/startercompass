# Same as setup but without the custom model (no resource pack needed).
execute at @s rotated ~ 0 positioned ^ ^ ^2 align xyz run function gacha:place_plain
tellraw @s {"text":"Plain Gacha Machine placed (a barrel with a floating label).","color":"green"}

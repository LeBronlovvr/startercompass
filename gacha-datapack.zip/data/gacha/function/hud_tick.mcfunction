scoreboard players set #t gacha_calc 0
execute as @a at @s if entity @e[type=marker,tag=gacha_machine,distance=..5] run function gacha:hud

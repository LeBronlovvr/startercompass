scoreboard players set #pay gacha_calc 0
scoreboard players set #cnt gacha_calc 0
data remove storage gacha:work items
data modify storage gacha:work items set from block ~ ~ ~ Items
function gacha:calc/loop

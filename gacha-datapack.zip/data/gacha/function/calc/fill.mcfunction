execute store result storage gacha:work fmt.pay int 1 run scoreboard players get #pay gacha_calc
execute store result storage gacha:work fmt.cnt int 1 run scoreboard players get #cnt gacha_calc
execute store result storage gacha:work fmt.vt int 1 run scoreboard players get #vt gacha_calc
data modify storage gacha:work fmt.name set from storage gacha:work target.name
data modify storage gacha:work fmt.color set from storage gacha:work target.color
data modify storage gacha:work fmt.tier set from storage gacha:work target.tier

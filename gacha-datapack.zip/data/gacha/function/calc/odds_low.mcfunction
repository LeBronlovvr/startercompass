scoreboard players operation #q gacha_calc = #pay gacha_calc
scoreboard players operation #q gacha_calc *= #k gacha_calc
scoreboard players operation #q gacha_calc /= #vt gacha_calc
scoreboard players operation #p gacha_calc = #q gacha_calc
scoreboard players operation #p gacha_calc *= #q gacha_calc
execute if score #p gacha_calc matches ..0 run scoreboard players set #p gacha_calc 1

function gacha:calc/payment
function gacha:calc/target
function gacha:calc/odds
function gacha:calc/format
function gacha:calc/fill

execute store result storage gacha:work q.i int 1 run scoreboard players get @s gacha_sel
function gacha:calc/target_m with storage gacha:work q

$data modify storage gacha:work target set from storage gacha:db items[$(i)]
$execute store result score #vt gacha_calc run data get storage gacha:db items[$(i)].value

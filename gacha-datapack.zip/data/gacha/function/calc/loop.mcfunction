execute unless data storage gacha:work items[0] run return 0
data modify storage gacha:work cur set from storage gacha:work items[0]
data remove storage gacha:work items[0]
function gacha:calc/item with storage gacha:work cur
function gacha:calc/loop

execute if score #f gacha_calc matches 0 run return 0
scoreboard players operation #m gacha_calc = #f gacha_calc
scoreboard players operation #m gacha_calc %= #10 gacha_calc
execute unless score #m gacha_calc matches 0 run return 0
scoreboard players operation #f gacha_calc /= #10 gacha_calc
scoreboard players remove #d gacha_calc 1
function gacha:calc/trim

scoreboard players set #p gacha_calc 0
execute if score #vt gacha_calc matches ..0 run return 0
execute if score #pay gacha_calc >= #vt gacha_calc run scoreboard players set #p gacha_calc 1000000000
execute if score #pay gacha_calc >= #vt gacha_calc run return 0
execute if score #pay gacha_calc matches 1.. run function gacha:calc/odds_low

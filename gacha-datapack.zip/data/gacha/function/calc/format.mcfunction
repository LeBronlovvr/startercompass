scoreboard players operation #w gacha_calc = #p gacha_calc
scoreboard players operation #w gacha_calc /= #1e7 gacha_calc
scoreboard players operation #f gacha_calc = #p gacha_calc
scoreboard players operation #f gacha_calc %= #1e7 gacha_calc
scoreboard players set #d gacha_calc 7
function gacha:calc/trim
scoreboard players set #len gacha_calc 1
execute if score #f gacha_calc matches 10.. run scoreboard players set #len gacha_calc 2
execute if score #f gacha_calc matches 100.. run scoreboard players set #len gacha_calc 3
execute if score #f gacha_calc matches 1000.. run scoreboard players set #len gacha_calc 4
execute if score #f gacha_calc matches 10000.. run scoreboard players set #len gacha_calc 5
execute if score #f gacha_calc matches 100000.. run scoreboard players set #len gacha_calc 6
execute if score #f gacha_calc matches 1000000.. run scoreboard players set #len gacha_calc 7
scoreboard players operation #z gacha_calc = #d gacha_calc
scoreboard players operation #z gacha_calc -= #len gacha_calc
data modify storage gacha:work fmt.dot set value "."
data modify storage gacha:work fmt.pad set value ""
execute if score #z gacha_calc matches 1 run data modify storage gacha:work fmt.pad set value "0"
execute if score #z gacha_calc matches 2 run data modify storage gacha:work fmt.pad set value "00"
execute if score #z gacha_calc matches 3 run data modify storage gacha:work fmt.pad set value "000"
execute if score #z gacha_calc matches 4 run data modify storage gacha:work fmt.pad set value "0000"
execute if score #z gacha_calc matches 5 run data modify storage gacha:work fmt.pad set value "00000"
execute if score #z gacha_calc matches 6 run data modify storage gacha:work fmt.pad set value "000000"
execute store result storage gacha:work fmt.f int 1 run scoreboard players get #f gacha_calc
execute if score #f gacha_calc matches 0 run data modify storage gacha:work fmt.dot set value ""
execute if score #f gacha_calc matches 0 run data modify storage gacha:work fmt.pad set value ""
execute if score #f gacha_calc matches 0 run data modify storage gacha:work fmt.f set value ""
execute store result storage gacha:work fmt.w int 1 run scoreboard players get #w gacha_calc

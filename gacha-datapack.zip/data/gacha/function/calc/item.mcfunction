$execute store result score #v gacha_calc run data get storage gacha:db by_id."$(id)"
execute if score #v gacha_calc matches ..0 run scoreboard players set #v gacha_calc 1
$scoreboard players set #n gacha_calc $(count)
scoreboard players operation #sum gacha_calc = #v gacha_calc
scoreboard players operation #sum gacha_calc *= #n gacha_calc
scoreboard players operation #pay gacha_calc += #sum gacha_calc
scoreboard players operation #cnt gacha_calc += #n gacha_calc

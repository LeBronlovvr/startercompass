scoreboard players set @s gacha_pull 0
execute if score @s gacha_anim matches 1.. run return 0
execute unless entity @e[type=marker,tag=gacha_machine,distance=..6] run tellraw @s {"text":"Stand next to a Gacha Machine to pull.","color":"red"}
execute unless entity @e[type=marker,tag=gacha_machine,distance=..6] run return 0
execute unless score @s gacha_sel matches 1.. run tellraw @s {"text":"Choose a prize first: /trigger gacha","color":"red"}
execute unless score @s gacha_sel matches 1.. run return 0
execute at @e[type=marker,tag=gacha_machine,distance=..6,limit=1,sort=nearest] run function gacha:pull_run

execute unless score @s gacha_sel matches 1.. run title @s actionbar {"text":"Gacha Machine  ▸  type /trigger gacha and choose your prize","color":"gold"}
execute unless score @s gacha_sel matches 1.. run return 0
execute at @e[type=marker,tag=gacha_machine,distance=..5,limit=1,sort=nearest] run function gacha:calc/all
execute if score #cnt gacha_calc matches 0 run function gacha:msg/hud_empty with storage gacha:work fmt
execute if score #cnt gacha_calc matches 0 run return 0
execute if score #cnt gacha_calc matches 65.. run function gacha:msg/hud_over with storage gacha:work fmt
execute if score #cnt gacha_calc matches 65.. run return 0
function gacha:msg/hud_ok with storage gacha:work fmt

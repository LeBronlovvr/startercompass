setblock ~ ~ ~ minecraft:barrel[facing=up]{CustomName:"Gacha Machine"} replace
summon minecraft:marker ~0.5 ~0.5 ~0.5 {Tags:["gacha_machine"]}
summon minecraft:item_display ~0.5 ~0.5 ~0.5 {Tags:["gacha_machine_model"],item:{id:"minecraft:amethyst_shard",count:1,components:{"minecraft:item_model":"gacha:gacha_machine"}},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.02f,1.02f,1.02f]}}
summon minecraft:text_display ~0.5 ~2.35 ~0.5 {Tags:["gacha_machine_label"],billboard:"center",text:{text:"✦ GACHA ✦",color:"gold",bold:true}}

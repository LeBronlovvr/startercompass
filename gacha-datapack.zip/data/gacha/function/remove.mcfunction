# Run as an operator while standing near a machine: removes the nearest one.
execute at @e[type=marker,tag=gacha_machine,distance=..8,limit=1,sort=nearest] run function gacha:remove_here

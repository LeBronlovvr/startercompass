execute at @e[type=marker,tag=gacha_machine,limit=1,sort=nearest] run kill @e[type=item_display,tag=gacha_fx,distance=..3]
execute if score @s gacha_win matches 1 run function gacha:anim/win
execute if score @s gacha_win matches 0 run function gacha:anim/lose

$data modify storage gacha:work won set from storage gacha:db items[$(i)]
function gacha:anim/win_do with storage gacha:work won
execute if score @s gacha_p matches ..9999999 run function gacha:anim/announce

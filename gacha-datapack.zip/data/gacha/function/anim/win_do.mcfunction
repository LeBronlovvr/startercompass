$give @s $(id) 1
title @s times 5 70 20
title @s title {"text":"★ YOU WON! ★","color":"gold","bold":true}
$title @s subtitle {"text":"$(name)","color":"$(color)"}
playsound minecraft:ui.toast.challenge_complete player @s ~ ~ ~ 1 1
playsound minecraft:entity.firework_rocket.twinkle block @a ~ ~ ~ 1 1
execute at @e[type=marker,tag=gacha_machine,limit=1,sort=nearest] run particle minecraft:totem_of_undying ~ ~1.7 ~ 0.6 0.6 0.6 0.3 60
$execute at @e[type=marker,tag=gacha_machine,limit=1,sort=nearest] run summon minecraft:item_display ~ ~2.0 ~ {Tags:["gacha_fx","gacha_reveal"],billboard:"center",item:{id:"$(id)",count:1},transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1.2f,1.2f,1.2f]}}
schedule function gacha:anim/cleanup 80t append

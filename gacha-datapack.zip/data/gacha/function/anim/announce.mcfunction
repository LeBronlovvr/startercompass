scoreboard players operation #p gacha_calc = @s gacha_p
function gacha:calc/format
data modify storage gacha:work fmt.name set from storage gacha:work won.name
data modify storage gacha:work fmt.color set from storage gacha:work won.color
function gacha:msg/announce with storage gacha:work fmt

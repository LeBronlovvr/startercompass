title @s times 5 50 15
title @s title {"text":"No luck...","color":"gray"}
title @s subtitle {"text":"Your offering was consumed. Try again!","color":"dark_gray"}
playsound minecraft:entity.villager.no player @s ~ ~ ~ 1 0.9
execute at @e[type=marker,tag=gacha_machine,limit=1,sort=nearest] run particle minecraft:smoke ~ ~1.7 ~ 0.4 0.4 0.4 0.05 25

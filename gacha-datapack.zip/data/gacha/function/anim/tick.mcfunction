scoreboard players remove @s gacha_anim 1
execute at @e[type=marker,tag=gacha_machine,limit=1,sort=nearest] run function gacha:anim/fx
execute if score @s gacha_anim matches 0 run function gacha:anim/reveal

kill @e[type=item_display,tag=gacha_reveal]

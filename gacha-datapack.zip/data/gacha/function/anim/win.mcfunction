execute store result storage gacha:work q.i int 1 run scoreboard players get @s gacha_idx
function gacha:anim/win_load with storage gacha:work q

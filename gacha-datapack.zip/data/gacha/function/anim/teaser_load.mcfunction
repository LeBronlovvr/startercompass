$data modify storage gacha:work target set from storage gacha:db items[$(i)]
function gacha:anim/teaser with storage gacha:work target

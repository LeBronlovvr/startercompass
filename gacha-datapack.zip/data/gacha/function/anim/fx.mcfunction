particle minecraft:enchant ~ ~1.7 ~ 0.5 0.4 0.5 0.4 6
execute as @e[type=item_display,tag=gacha_fx,distance=..3] at @s run rotate @s ~18 ~
execute if score @s gacha_anim matches 48 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.5
execute if score @s gacha_anim matches 44 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.56
execute if score @s gacha_anim matches 40 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.63
execute if score @s gacha_anim matches 36 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.7
execute if score @s gacha_anim matches 32 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.79
execute if score @s gacha_anim matches 28 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 0.89
execute if score @s gacha_anim matches 24 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.0
execute if score @s gacha_anim matches 20 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.12
execute if score @s gacha_anim matches 16 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.26
execute if score @s gacha_anim matches 12 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.41
execute if score @s gacha_anim matches 8 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.59
execute if score @s gacha_anim matches 4 run playsound minecraft:block.note_block.bell block @a ~ ~1 ~ 1 1.78

scoreboard players operation @s gacha_sel = @s gacha_pick
scoreboard players set @s gacha_pick 0
execute if score @s gacha_sel > #nitems gacha_calc run scoreboard players set @s gacha_sel 0
execute unless score @s gacha_sel matches 1.. run return 0
execute store result storage gacha:work q.i int 1 run scoreboard players get @s gacha_sel
function gacha:msg/picked_load with storage gacha:work q
dialog show @s gacha:main

scoreboard players set @s gacha_odds 0
execute unless entity @e[type=marker,tag=gacha_machine,distance=..6] run tellraw @s {"text":"Stand next to a Gacha Machine to check your odds.","color":"red"}
execute unless entity @e[type=marker,tag=gacha_machine,distance=..6] run return 0
execute unless score @s gacha_sel matches 1.. run tellraw @s {"text":"Choose a prize first: /trigger gacha","color":"red"}
execute unless score @s gacha_sel matches 1.. run return 0
execute at @e[type=marker,tag=gacha_machine,distance=..6,limit=1,sort=nearest] run function gacha:calc/all
function gacha:msg/odds with storage gacha:work fmt
execute if score #cnt gacha_calc matches 65.. run tellraw @s {"text":"Too many items: the machine takes at most 64 in total.","color":"red"}
scoreboard players operation #vt2 gacha_calc = #vt gacha_calc
scoreboard players operation #vt2 gacha_calc *= #2 gacha_calc
execute if score #pay gacha_calc > #vt2 gacha_calc run tellraw @s {"text":"Tip: your payment is worth more than twice the prize. Take some items out to save them!","color":"yellow"}

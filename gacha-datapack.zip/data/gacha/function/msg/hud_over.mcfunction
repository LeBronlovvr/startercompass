$title @s actionbar ["",{"text":"$(name)","color":"$(color)","bold":true},{"text":"  ▸  too many items! ($(cnt)/64)","color":"red"}]

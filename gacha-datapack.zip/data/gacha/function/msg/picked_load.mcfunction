$data modify storage gacha:work target set from storage gacha:db items[$(i)]
function gacha:msg/picked with storage gacha:work target

$title @s actionbar ["",{"text":"$(name)","color":"$(color)","bold":true},{"text":"  ▸  put items into the machine (value $(vt) is a guaranteed win)","color":"gray"}]

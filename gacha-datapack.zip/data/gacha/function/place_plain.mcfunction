setblock ~ ~ ~ minecraft:barrel[facing=up]{CustomName:"Gacha Machine"} replace
summon minecraft:marker ~0.5 ~0.5 ~0.5 {Tags:["gacha_machine"]}
summon minecraft:text_display ~0.5 ~1.4 ~0.5 {Tags:["gacha_machine_label"],billboard:"center",text:{text:"✦ GACHA ✦",color:"gold",bold:true}}

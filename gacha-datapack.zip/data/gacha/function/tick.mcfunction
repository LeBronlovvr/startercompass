scoreboard players enable @a gacha
scoreboard players enable @a gacha_pick
scoreboard players enable @a gacha_pull
scoreboard players enable @a gacha_odds
execute as @a[scores={gacha=1..}] run function gacha:open
execute as @a[scores={gacha_pick=1..}] run function gacha:pick
execute as @a[scores={gacha_odds=1..}] at @s run function gacha:odds_cmd
execute as @a[scores={gacha_pull=1..}] at @s run function gacha:pull
execute as @a[scores={gacha_anim=1..}] at @s run function gacha:anim/tick
scoreboard players add #t gacha_calc 1
execute if score #t gacha_calc matches 10.. run function gacha:hud_tick

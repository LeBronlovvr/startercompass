function gacha:calc/all
execute if score #cnt gacha_calc matches 0 run tellraw @s {"text":"Put some items into the Gacha Machine first.","color":"red"}
execute if score #cnt gacha_calc matches 0 run return 0
execute if score #cnt gacha_calc matches 65.. run tellraw @s {"text":"Too many items! The machine takes at most 64 in total.","color":"red"}
execute if score #cnt gacha_calc matches 65.. run return 0
item replace block ~ ~ ~ container.0 with minecraft:air
item replace block ~ ~ ~ container.1 with minecraft:air
item replace block ~ ~ ~ container.2 with minecraft:air
item replace block ~ ~ ~ container.3 with minecraft:air
item replace block ~ ~ ~ container.4 with minecraft:air
item replace block ~ ~ ~ container.5 with minecraft:air
item replace block ~ ~ ~ container.6 with minecraft:air
item replace block ~ ~ ~ container.7 with minecraft:air
item replace block ~ ~ ~ container.8 with minecraft:air
item replace block ~ ~ ~ container.9 with minecraft:air
item replace block ~ ~ ~ container.10 with minecraft:air
item replace block ~ ~ ~ container.11 with minecraft:air
item replace block ~ ~ ~ container.12 with minecraft:air
item replace block ~ ~ ~ container.13 with minecraft:air
item replace block ~ ~ ~ container.14 with minecraft:air
item replace block ~ ~ ~ container.15 with minecraft:air
item replace block ~ ~ ~ container.16 with minecraft:air
item replace block ~ ~ ~ container.17 with minecraft:air
item replace block ~ ~ ~ container.18 with minecraft:air
item replace block ~ ~ ~ container.19 with minecraft:air
item replace block ~ ~ ~ container.20 with minecraft:air
item replace block ~ ~ ~ container.21 with minecraft:air
item replace block ~ ~ ~ container.22 with minecraft:air
item replace block ~ ~ ~ container.23 with minecraft:air
item replace block ~ ~ ~ container.24 with minecraft:air
item replace block ~ ~ ~ container.25 with minecraft:air
item replace block ~ ~ ~ container.26 with minecraft:air
execute store result score #roll gacha_calc run random value 1..1000000000
scoreboard players set @s gacha_win 0
execute if score #roll gacha_calc <= #p gacha_calc run scoreboard players set @s gacha_win 1
scoreboard players operation @s gacha_idx = @s gacha_sel
scoreboard players operation @s gacha_p = #p gacha_calc
scoreboard players set @s gacha_anim 50
title @s times 5 40 10
title @s title {"text":"Pulling...","color":"gold"}
title @s subtitle {"text":"Good luck!","color":"yellow"}
playsound minecraft:block.beacon.activate block @a ~ ~1 ~ 1 1.3
function gacha:anim/teaser_load with storage gacha:work q

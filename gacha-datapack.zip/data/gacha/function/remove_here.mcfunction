kill @e[type=item_display,tag=gacha_machine_model,distance=..2]
kill @e[type=text_display,tag=gacha_machine_label,distance=..3]
setblock ~ ~ ~ minecraft:air destroy
kill @e[type=marker,tag=gacha_machine,distance=..1,limit=1]
